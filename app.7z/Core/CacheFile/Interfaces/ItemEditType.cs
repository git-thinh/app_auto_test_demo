﻿using System;
using System.Collections.Generic;
using System.Text;

namespace app.Core
{
    public enum ItemEditType
    {
        ADD_NEW_ITEM = 1,
        REMOVE_ITEM = 2,
    }
}
