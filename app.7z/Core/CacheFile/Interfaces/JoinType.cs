﻿using System;
using System.Collections.Generic;
using System.Text;

namespace app.Core
{ 
    public enum JoinType
    {
        NONE = 0,
        DEF_VALUE = 1,
        JOIN_MODEL = 2,
    }
}
