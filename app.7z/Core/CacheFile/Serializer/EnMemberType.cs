﻿ 

namespace app.Core.CacheFile
{
	enum EnMemberType
	{
		Object,
		Property,
		Field
	}
}
