
using System;

namespace Sano.Utility.NativeMethods {

	public struct RasterOperationCodes {

		public const int SRCCOPY = 0x00CC0020;

	}

}