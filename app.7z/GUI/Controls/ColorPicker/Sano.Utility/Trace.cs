using System;

namespace Sano.Utility {

	public class Trace {

	}

}