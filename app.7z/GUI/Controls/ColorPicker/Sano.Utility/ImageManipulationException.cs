
using System;

namespace Sano.Utility.NativeMethods {

	public class ImageManipulationException : ApplicationException {

		public ImageManipulationException( string message ) : base( message ) { }

	}

}