﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sano.PersonalProjects.ColorPicker.Controls
{
  public  class ___Const_ColorPicker
    {
      public const string Path_Resource = "app.GUI.Controls.ColorPicker.";
    }
}
