using System;

namespace Sano.PersonalProjects.ColorPicker.Controls {
	internal delegate void ColorSwatchSelectedHandler( object sender, ColorSelectedEventArgs e );
}
