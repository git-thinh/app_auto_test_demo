using System;

namespace Sano.PersonalProjects.ColorPicker.Controls {

	internal interface IColorSpaceStructure {}

}
