
using System;

namespace Sano.PersonalProjects.ColorPicker.Controls {

	internal enum ComponentUnit {
		Degree,
		Percentage,
		Value
	}

}