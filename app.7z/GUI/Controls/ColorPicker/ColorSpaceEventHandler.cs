
using System;

namespace Sano.PersonalProjects.ColorPicker.Controls {
	internal delegate void ColorSpaceEventHandler( ColorSpace sender, EventArgs e );
}