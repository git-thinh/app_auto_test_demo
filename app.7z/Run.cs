﻿using System;
using System.Collections.Generic;
using System.Text;

namespace app
{
    class Run
    {
        static void Main(string[] args)
        {
            App.Start();   
        }
    }
}
